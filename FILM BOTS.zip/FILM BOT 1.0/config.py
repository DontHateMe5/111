#By кот хакер 1234#
#Downloaded from TG @top_softs
#Leave this inscription#

token='6103055351:AAGWapn4rJuM__7QLIz34A7m25hxv53Ix_w' #https://t.me/BotFather 
admin_id=int(102952632) #https://t.me/getidsbot 

